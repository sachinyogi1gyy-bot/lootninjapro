package com.loot.ninja.pro;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    AdsManager adsManager;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        adsManager = new AdsManager(this);

        findViewById(R.id.btnAd).setOnClickListener(v -> {
            adsManager.showAd();
        });
    }
}