package com.loot.ninja.pro;

import android.app.Activity;
import com.unity3d.ads.*;

public class AdsManager implements IUnityAdsShowListener {

    Activity activity;

    public AdsManager(Activity activity) {
        this.activity = activity;
        UnityAds.initialize(activity, "6098349", false);
    }

    public void showAd() {
        UnityAds.show(activity, "Rewarded_Android", this);
    }

    @Override
    public void onUnityAdsShowComplete(String placementId, UnityAdsShowCompletionState state) {
        if (state == UnityAdsShowCompletionState.COMPLETED) {
            ApiClient.rewardUser();
        }
    }

    public void onUnityAdsShowFailure(String s, UnityAds.UnityAdsShowError e, String msg) {}
    public void onUnityAdsShowStart(String s) {}
    public void onUnityAdsShowClick(String s) {}
}