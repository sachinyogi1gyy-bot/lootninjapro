package com.loot.ninja.pro;

import com.google.firebase.auth.FirebaseAuth;
import okhttp3.*;

public class ApiClient {

    public static void rewardUser() {

        FirebaseAuth.getInstance().getCurrentUser()
            .getIdToken(true)
            .addOnSuccessListener(result -> {

                String token = result.getToken();

                OkHttpClient client = new OkHttpClient();

                Request request = new Request.Builder()
                    .url("https://your-backend.com/reward")
                    .addHeader("Authorization", "Bearer " + token)
                    .post(RequestBody.create(new byte[]{}))
                    .build();

                client.newCall(request).enqueue(new Callback() {
                    public void onFailure(Call call, java.io.IOException e) {}
                    public void onResponse(Call call, Response response) {}
                });

            });
    }
}